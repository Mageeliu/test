## 自定义组件
  + 种类
    - 路由组件：views目录下的vue文件
    - 复用组件：components目录下的vue文件
  + 创建
    - template
      - 有且仅有一个顶层标签
      - 添加class，属性和事件
    - script
      - name：定义当前组件的名称
      - data：定义当前组件中的数据
      - props：接收父组件传入的参数
      - components：添加其他自定义组件
      - methods：定义当前组件中的函数
      - mounted：调用当前组件中的函数
    - style
      - lang属性为scss
      - 添加scoped
  + 使用
    - 引入：import 名称 from 地址
    - 添加：在当前组件的components中添加引入的组件
    - 使用
      - 在当前组件的template中，像标签一样使用
      - 使用属性的方式向子组件传递参数
      - 使用事件的方式接收子组件的参数
      
## 第三方组件（mint-ui中的loadmore）
  + template
    ```
    <mt-loadmore :top-method="loadTop" :bottom-method="loadBottom" :bottom-all-loaded="allLoaded" ref="loadmore" :auto-fill="false">
        <!-- 你的列表 -->
    </mt-loadmore>  
    ```
  + script
    - data
      - goodsList：当前组件的列表数据
      - allLoaded：所有的列表数据是否已经加载完毕
      - pageNum：页数
    - methods
      - reqGoodsList：请求获取列表数据
      - loadTop：下拉刷新时触发的函数
      - loadBottom：上拉加载更多时触发的函数
    - mounted: 调用下拉刷新的函数
  + style
    - 给组件的容器添加一个固定的高度
    - 给组件的容器添加溢出滚动
    
## 缓存
  + keep-alive
    - 加在router-view的外面
    - 添加include，exclude
  + 生命周期函数
    - activated：进入缓存组件
    - deactivated：离开缓存路由
  + 无法记录上次滚动的位置
    - 在deactivated中保存滚动位置
    - 在beforeRouteLeave中保存滚动位置，早于deactivated
    
## 练习
  + 学会自己封装组件
  + 学会使用mint-ui的loadmore
  + 写一个商品列表，至少包含下拉刷新，上拉加载更多和关键字查询