## 前端
  + 打开项目根目录下的vue.config.js
    - 配置html文件中href和src的路径抬头
      ```
      publicPath: process.env.NODE_ENV == 'development' ? '/' : ''
      ```
    - 配置开发环境下的反向代理
      ```
      devServer: {
        proxy: {
          '/xiaobu/api': {
            target: 'http://localhost:8888',
            changeOrigin: true,
            pathRewrite: {
                '^/xiaobu/api': ''
            }
          }            
        }
      }  
      ```
  + 打开项目根目录下的main.js，配置请求域
      ```
      /*
        开发环境下，是本地服务器的IP和端口号
        生产环境下，是线上服务器的IP(或者域名)和端口号
      */
      const commonUrl = (process.env.NODE_ENV == 'development') ? 'http://192.168.50.42:8888' : 'http://公网IP:8888'      

      /*
        将公共的请求域添加到Vue原型上，这样每个vue文件中都能获取到它
        主要是用于拼接从自己的服务器返回的图片路径
      */
      Vue.prototype.$commonUrl = commonUrl
      ```
  + 打开项目根目录下的router.js，不要设置mode属性，或者让它取默认值hash
  + 在所有的vue文件中
    - axios的请求路径的抬头是/xiaobu/api
    - 图片的src
      - 如果是从本地拿图片
        - 当路径被写死，src的格式为../assets/img/logo.png
        - 当路径是变量，src的格式为:src="require(`../assets/img/{name}.png`)"
      - 如果是从服务器返回图片  
        - 从自己的服务器上拿，src的格式为:src="$commonUrl + item.goodsImg"
        - 从别人的服务器上扣，src的格式为http://www.baidu.com/logo.jpg
  + 最后，运行打包命令，将最终的项目文件，导出到项目根目录下的dist目录
    ```
    npm run build
    ```

## 后端
  + 端口号
    - 不要写成80
    - 如果是多人共用一台服务器，端口号不能出现重复
  + 图片
    - 配置静态资源目录
      ```
      app.use(express.static(path.join(__dirname, 'public')))
      ```
    - 将自己服务器上的图片，全部放在public目录下的images目录中
  + 数据库
    - 命名为xiaobu
		- 在db/connect.js文件中，连接的地址为mongodb://localhost/xiaobu
    - 图片路径
      - 如果是从自己的服务器返回图片，路径都以/抬头，类似/images/1.jpg
      - 如果是从别人的服务器上扣图片，路径保持原样，类似http://www.baidu.com/logo.jpg

## 运维
  + 购买
    - 优先选择学生优惠
    - 系统镜像：centos
    - 尽量超过3个月
  + 设置
    - 添加安全组规则
      - 协议：TCP
      - 端口范围：1/60000
    - 设置远程连接密码，成功之后需要重启服务器
  + 连接
    - xshell：用于输入命令
      - 第一次，点击创建连接
        - 输入连接名
        - 主机是公网IP
        - 协议是SSH
        - 在左侧边栏中选择用户身份验证，用户名是root，密码是远程连接密码
        - 点击连接，在弹窗中选择接受并保存
      - 在绿色的光标后面，输入linux命令
        - 查看当前目录：pwd
        - 定位到根目录：cd /
        - 查看当前目录下的所有子目录和文件：list
        - 移动光标
          - 移到开头：ctrl + a
          - 移到结尾：ctrl + e
          - 在单词之间跳转：ctrl + 左右键  
    - xftp：用于传输文件
      - 第一次，点击新建连接
        - 输入连接名
        - 主机是公网IP
        - 协议是SFTP
        - 勾选使用身份验证代理，用户名是root，密码是远程连接密码
      - 左边是本地目录，右边是远程服务器上的目录
        - 在左边，定位到本地的服务器目录
        - 在右边，定位到远程服务器上的根目录，新建一个文件夹叫xiaobu
        - 在右边，点击进入刚才创建好的文件夹
        - 在左边，选中除去node_modules之外的所有的文件夹和文件，右键选择传输

  + 安装
    - 在任意位置执行以下命令
      ```
      yum install epel-release -y
      yum install nodejs -y
      yum install nginx -y
      
      yum update openssl -y
      ```
    - 进入NodeJS目录，再安装第三方模块
      ```
      cd /xiaobu
      npm install

      npm install pm2 -g
      ```
  + mongodb
    - 新建
      - 定位到根目录
        ```
        cd /
        ```
      - 新建一个目录，叫tools
        ```
        mkdir tools
        ```
      - 进入这个目录
        ```
        cd tools
        ```
    - 下载
      ```
      wget -c https://fastdl.mongodb.org/linux/mongodb-linux-x86_64-3.2.1.tgz
      ```
    - 解压
      ```
      tar -zxvf mongodb-linux-x86_64-3.2.1.tgz
      ```
    - 移动
      ```
      mv mongodb-linux-x86_64-3.2.1 /usr/local/mongodb
      ```
    - 添加
      - 进入mongodb目录
        ```
        cd /usr/local/mongodb
        ```
      - 新建两个文件夹，分别叫data和logs
        ```
        mkdir data
        mkdir logs
        ```
      - 进入log目录
        ```
        cd logs
        ```
      - 新建一个文件，叫mongo.log
        ```
        touch mongo.log
        ```
    - 配置
      - 打开配置文件
        ```
        vim /etc/profile
        ```
      - 修改配置文件
        - 按下Insert键或者i，左下角出现INSERT，表示进入编辑模式
        - 复制以下代码到文件中
          ```
          export MONGODB_HOME=/usr/local/mongodb
          export PATH=$MONGODB_HOME/bin:$PATH
          ```
      - 保存修改并退回命令行       
        - 按下Esc键
        - 先输入冒号，然后输入wq
        - 最后回车
      - 重新加载配置文件
        ```
        source /etc/profile
        ```
    - 启动
      ```
      mongod --dbpath=/usr/local/mongodb/data --logpath=/usr/local/mongodb/logs/mongo.log --logappend --port=27017 --fork
      ```
    - 导入
      - 从本地数据库导出
        - 打开studio 3t，新建连接，连接名叫dev，server为localhost
        - 右键选中dev的xiaobu，点击export，选择json格式，将数据导出到某个文件夹中
      - 导入到远程数据库
        - 打开studio 3t，新建连接，连接名叫prod，server为公网IP
        - 右键选中prod，新建一个数据库，名字叫xiaobu
        - 右键选中prod的xiaobu，点击import，选择json格式，导入刚才存放数据的文件夹
  + 服务
    - npm
      - 特点
        - 使用npm命令，启动NodeJS服务
        - 可以查看服务器的报错信息
        - 如果关掉xshell或者电脑，服务就会断开
      - 操作
        - 定位到自己的服务器目录
          ```
          cd /xiaobu
          ```
        - 输入npm命令，开启一个NodeJS服务
          ```
          npm run server
          ```
        - 在浏览器输入一个get请求地址，看页面是否报错
    - pm2
      - 特点
        - 使用pm2命令，挂起NodeJS服务
        - 无法查看服务器的报错信息
        - 即使关掉xshell或者电脑，服务都不会断开
      - 操作
        - 定位到自己的服务器目录
          ```
          cd /xiaobu
          ```			
        - 挂起一个NodeJS服务
          ```
          pm2 start nodemon ./bin/www
          ```
        - 查看所有被挂起的服务，以及对应的服务ID
          ```
          pm2 list
          ```
        - 重启一个被挂起的服务
          ```
          pm2 restart 服务ID
          ```
        - 关闭一个被挂起的服务
          ``` 
          pm2 stop 服务ID
          ```
        - 再次打开刚才被关闭的服务
          ```
          pm2 start 服务ID
          ```
  + nginx
	  - 开启nginx服务，直接输入nginx
    - 上传前端项目
      - 打开xftp
      - 在左边，定位到前端项目的dist目录，点击进去
      - 在右边，定位到/usr/share/nginx/html，点击进去
      - 在右边，新建一个文件夹，名称叫xiaobu，点击进去
      - 在左边，选中所有的目录和文件，右键选择传输
    - 修改配置文件
      - 定位到nginx的配置文件目录
      	```
      	cd /etc/nginx
      	```
      - 打开当前目录下的配置文件
        ```
        vim nginx.conf
        ```
      - 添加反向代理，不要掉了斜杠和分号
        ```
        location /xiaobu/api/ {
            proxy_pass http://localhost:8888/;
        }
        ```
      - 保存修改并退回命令行       
        - 按下Esc键
        - 先输入冒号，然后输入wq
        - 最后回车
      - 重启nginx服务，让刚才的修改生效
        ```
        nginx -s reload
        ```
  + 迭代
    - 修改前端代码
      - 重新打包
        ```
        npm run build
        ```
      - 上传文件
        - 打开xftp
        - 在左边，定位到前端项目的dist目录，点击进去
        - 在右边，定位到/usr/share/nginx/html/xiaobu
        - 在左边，选中所有的目录和文件，右键选择传输，进行覆盖
    - 修改后端代码
      - 打开xftp
      - 在左边，定位到后端项目，点击进去
      - 在右边，定位到/xiaobu
      - 在左边，选中发生改变的文件，右键选择传输，进行覆盖
      - 查看服务
        ```
        pm2 list
        ```
      - 重启服务
        ```
        pm2 restart 服务ID
        ```
  
## Git
  + 配置用户名和邮箱名
    ```
    git config --global user.name '用户名'
    git config --global user.email '邮箱名'
    git config --list
    ```
  + 初始化本地仓库
    - 显示隐藏文件，删除所有子目录中的.git文件
    - 在根目录下执行git init，会在根目录下多出一个.git文件
    - 在根目录下新建一个.gitignore
      ```
      node_modules
      **/node_modules
      ```
  + 新建远程仓库：点击加号创建仓库，输入仓库名称、简介和是否开源
  + 连接远程仓库
    - 查看本地密钥
      ```
      cd ~/.ssh
      ls
      ```
    - 生成两个密钥
      ```
      ssh-keygen -t rsa -C '注释'
      ls
      ```
    - 查看公钥文件
      ```
      cat id_rsa.pub
      ```
    - 将公钥放到远程仓库
      - 本地：复制公钥
      - 远程：打开设置，点击SSH公钥，输入标题，粘贴公钥
    - 测试连接
      ```
      ssh -T git@gitee.com
      ```
    - 建立连接
      ```
      git remote add origin git@gitee.com:用户名/仓库名.git
      ```
    - 同步记录
      ```
      git pull origin master
      ```
  + 提交项目代码
    - 查看文件状态
      ```
      git status
      ```
    - 将文件添加到暂存区
      ```
      git add .
      ```
    - 将文件提交到版本库
      ```
      git commit -m '注释'
      ```
    - 拉取远程项目
      ```
      git pull origin master
      ```
    - 推送本地项目
      ```
      git push orign master
      ```