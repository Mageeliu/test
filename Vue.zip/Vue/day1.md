## [介绍](https://cn.vuejs.org/)
  + Vue是什么
    - 前端框架
    - 三足鼎立
    - 国人开发
  + 为什么学它
    - 市场需求
    - 提高效率
    - 上手简单

## [Vue-cli](https://cli.vuejs.org/zh/)
  + 安装
    ```
    npm install @vue/cli -g
    ```
  + 生成
    ```
    vue create myvue
    ```
  + 勾选
    - babel：将ES6转成ES5
    - router：路由
    - vuex：状态管理
    - css pre-processors：css预处理器
  + 选择
    - 不使用history模式
    - 使用sass with node-sass
  + 其他
    - vscode插件：vetur，vue 2 snippets
    - vue-devtools
    
## 结构
  + package.json：使用npm命令局部安装的第三方模块
    - 结尾是--save，这个模块就被记录在dependencies中
    - 结尾是--save-dev，就被记录在devDependencies中
  + node_modules：第三方模块的局部安装位置
  + babel.config.js：babel的配置文件
  + postcss.config.js：postcss的配置文件叫
  + .gitignore：git项目中的一个配置文件，用于告诉Git哪些文件不需要添加到版本管理中
  + src：项目源代码目录，在项目开发过程中，存放vue代码的地方
    - main.js：入口文件
    - router.js：前端路由的配置文件
    - store.js：vuex的配置文件
    - app.vue：根组件
    - views：路由组件
    - components：在路由组件中引入的其他组件
    - asssets：在vue文件中使用相对路径引入的资源文件
  + public：存放的是项目模板文件，以及所有通过src或者href引入的外部文件
  + readme.md：项目的使用文档，就是教你怎么使用这个vue脚手架

## 语法
  + mustache
    - 放data定义中的变量
    - 放表达式
      - 数学运算
      - 字符串拼接
      - 调用方法
      - 三目运算符
  + v-前缀
    - 解析html：v-html
    - 绑定属性：v-bind:或者:
    - 绑定事件：v-on:或者@
    - 条件渲染
      - v-if，v-else-if，v-else
      - v-show
    - 列表渲染
      - v-for
      - 添加key
    - 双向绑定
      - 表单控件
      - v-model
  + 函数
    - 定义：methods
    - 使用
      - 对于事件监听函数，在标签中直接写函数名
      - 对于内部封装函数，直接使用this点函数名
    - 参数
      - 默认参数
      - 外部参数      
  + 生命周期函数
    - created：可以获取this，但当前组件的DOM节点还未生成
    - mounted：当前组件的DOM节点已经生成
    - updated：当前组件的数据发生改变，并且导致DOM节点发生相应的变化
    
## 组件    
  + 种类
    - 内置：router-link，router-view
    - 自定义：后缀名为vue的文件
    - 第三方：mint-ui
  + 传参
    - 父往子
      - 父：使用绑定属性的方式进行传递
      - 子：使用props接收
    - 子往父
      - 子：使用$emit方法发送事件，带上参数
      - 父：使用绑定事件的方式捕获事件，获取默认参数
    
## 练习
  + 使用vue-cli搭建一个vue项目
  + 消化今天讲到的知识点
  + 安装mint-ui和axios