## 语法
  + 列表渲染
    - v-for
      - item：元素
      - index：索引
    - key
      - 表示以哪种方式更新当前列表
      - 一般取数组下标，或者每个数组元素的唯一标识
      - 不能重复
  + 生命周期函数
    - created：可以获取this，但当前组件的DOM节点还未生成
    - mounted：当前组件的DOM节点已经生成
    - updated：当前组件的数据发生改变，并且导致DOM节点发生相应的变化
    - destroyed：当前组件被销毁

## [Mint-UI](https://mint-ui.github.io/docs/#/zh-cn2)
  + 安装
    ```
    npm install mint-ui --save
    ```
  + 引入：在main.js中添加以下内容
    ```
    import MintUI from 'mint-ui'
    import 'mint-ui/lib/style.css'
    Vue.use(MintUI)
    ```
  + 使用：在vue文件中
    - 在template中，当成标签来使用
    - 向组件传入参数，参数是已知的值，也可以是一个变量
    - 使用/deep/向第三方组件里面的子组件进行样式的渗透

## [axios](https://www.kancloud.cn/yunye/axios/234845)
  + 安装
    ```
    npm install axios --save
    ```
  + 配置：在main.js文件中添加以下内容
    ```
    import axios from 'axios'
    import {Indicator} from 'mint-ui'
    axios.interceptors.request.use(function(config){
        Indicator.open('加载中')

        return config
    }, function (error) {
        return Promise.reject(error)
    });
    axios.interceptors.response.use(function(response){
        Indicator.close()

        return response.data
    }, function (error) {
        return Promise.reject(error)
    })
    Vue.prototype.$axios = axios    
    ```
  + 使用
    - 在某个vue文件中，通过this.$axios进行调用
    - 方法是请求方式，第一个参数是请求路径，第二个参数是请求参数
    - 执行结果是一个promise对象
  + 图片
    - 服务器返回的图片路径不带前面的http://locahost:8888
    - 在前端手动拼接
      - 在main.js文件中添加以下内容
        ```
        const commonUrl =  `http://${process.env.NODE_ENV == 'development' ? 'localhost' : 'xiaobulaoshi.club'}:8888`
        Vue.prototype.$commonUrl = commonUrl
        ```
      - 在服务器返回的图片路径前面添加$commonUrl    
  + 代理
    - 在vue.config.js文件中添加以下内容
      ```
      module.exports = {
          devServer: {
              proxy: {
                  '/api': {
                      target: 'http://localhost:8888',
                      changeOrigin: true,
                      pathRewrite: {
                          '^/api': ''
                      }
                  }
              }
          }
      }    
      ```
    - 将请求地址中的http://locahost:8888，改成/api

## 练习
  + 学会使用第三方组件Mint-UI
  + 牢记axios、图片路径和反向代理的配置
  + 写一个首页，包含吸顶、轮播图和列表