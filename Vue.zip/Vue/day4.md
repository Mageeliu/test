## 动态路由
  + 路由路径
    - 配置：添加/:id
    - 使用：添加/具体的id
  + 跳转路由
    - 使用router-link
    - 使用this.$router
      - 方法：push、replace或者back
      - 参数：字符串，对象。
  + 获取参数
    - 使用this.$route获取路由信息
    - 使用watch监听$route
    
## 组件插槽
  + 作用：相当于一个占位符，接收父组件传入的内容
  + 使用
    - 子组件
      ```
        <div class="container">
            <header>
                <slot name="header"></slot>
            </header>
            
            <main>
                <slot></slot>
            </main>
            
            <footer>
                <slot name="footer"></slot>
            </footer>
        </div>
      ```
    - 父组件
      ```
        <MyForm>
            <template v-slot:header>
                <h1>头部区域</h1>
            </template>
        
            <p>中间内容</p>
        
            <template v-slot:footer>
                <p>底部区域</p>
            </template>
        </MyForm>
      ```
      